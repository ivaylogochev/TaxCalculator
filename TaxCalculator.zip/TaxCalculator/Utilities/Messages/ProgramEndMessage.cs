﻿namespace TaxCalculator.Utilities.Messages
{
    public class ProgramEndMessage
    {
        public const string END = "END";
    }
}
