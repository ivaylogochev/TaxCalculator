﻿namespace TaxCalculator.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
