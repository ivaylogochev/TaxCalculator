﻿namespace TaxCalculator.Core.Contracts
{
    public interface IEngine
    {
       void Run();
    }
}
